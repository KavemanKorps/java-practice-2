import calculator.calculator;

public class Driver {
    public static void main(String[] args) throws Exception {
        calculator calc = new calculator();
        calc.runCalc();
    }
}
