import checkpali.checkpali;

public class Driver {
    public static void main(String[] args) throws Exception {
        checkpali checker = new checkpali();
        checker.runcode();
    }
}
